<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f6b0292056a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Subscription\Frontend; use Pmpr\Common\Foundation\Frontend\Page as BaseClass; abstract class Page extends BaseClass { }
