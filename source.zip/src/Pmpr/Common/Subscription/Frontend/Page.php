<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae85534c7a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Subscription\Frontend; use Pmpr\Common\Foundation\Frontend\Page as BaseClass; abstract class Page extends BaseClass { }
