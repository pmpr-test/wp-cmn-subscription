<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d5eb317b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Subscription; use Pmpr\Common\Foundation\Container\CommonInitiator; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Subscription\Woocommerce\Woocommerce; class Subscription extends CommonInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [Constants::qescuiwgsyuikume => static function () { return __("\103\x6f\x6d\x6d\x6f\x6e\40\123\x75\x62\163\143\x72\x69\x70\x74\151\x6f\156", PR__CMN__COVER); }, Constants::wuowaiyouwecckaw => false]); } public function mameiwsayuyquoeq() { Woocommerce::symcgieuakksimmu(); } }
