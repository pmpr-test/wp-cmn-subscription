<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d5eb317b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Subscription\Interfaces; use Pmpr\Common\Subscription\Engine; interface EngineInterface { public function uykissogmuaaocsg() : Engine; }
