<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6800f85c949b9             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Subscription\Woocommerce; use Pmpr\Common\Subscription\Container; class Woocommerce extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu('plugins_loaded', [$this, 'icwcgmcoimqeigye']); } public function icwcgmcoimqeigye() { if ($this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai()) { Setting::symcgieuakksimmu(); } } }
