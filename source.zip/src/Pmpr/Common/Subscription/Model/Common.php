<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a8153e41             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Subscription\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Common\Subscription\Interfaces\EngineInterface; abstract class Common extends Model implements EngineInterface { }
