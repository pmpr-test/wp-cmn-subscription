<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6800f6f59c461             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Subscription\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Common\Subscription\Interfaces\EngineInterface; abstract class Common extends Model implements EngineInterface { }
